const POSITION = 'panel-position-key';
